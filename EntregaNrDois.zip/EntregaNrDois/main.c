/* Sistemas Operativos 2020-21
   Segunda Entrega 
   Francisco Paiva 96737
   Joao Rebolo 96748
*/

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include <ctype.h>
#include "fs/threadprocess.h"
#include "fs/operations.h"

#define MAX_COMMANDS 150000
#define MAX_INPUT_SIZE 100

int numberThreads = 0;
struct timeval tvalBefore;

char inputCommands[MAX_COMMANDS][MAX_INPUT_SIZE];
int numberCommands = 0;

/* Condition Variables */
pthread_cond_t podeProd;
pthread_cond_t podeCons;

int prodptr = 0;
int consptr = 0;

/* Inputfile */
char* inputFile = NULL;




void* applyCommands();

/* Function that counts the execution time of the program*/
void count_time(){
    struct timeval tvalAfter;
    gettimeofday(&tvalAfter, NULL);
    
    long seconds = (tvalAfter.tv_sec - tvalBefore.tv_sec);
    long micros = ((seconds * 1000000) + tvalAfter.tv_usec)-(tvalBefore.tv_usec);

    printf("TecnicoFS completed in %ld.%.4ld seconds.\n",seconds, micros);
}

/* Function that checks input writen in the terminal */
void checkinput(int argc,char* filename, char* numtread){
    if(argc != 4){
        fprintf(stderr, "Error: Number of arguments is incorrect\n");
        exit(EXIT_SUCCESS);
    }
    if(atoi(numtread) < 1){
        fprintf(stderr, "Error: Amount of threads is incorrect\n");
        exit(EXIT_SUCCESS);
    }
    /* Input file (global variable)*/
    inputFile = filename;
    
    /*thread variable (global variable)*/
    numberThreads = atoi(numtread);
}


int insertCommand(char* data) {
    lock_global();
    while(numberCommands == MAX_COMMANDS){
        if(pthread_cond_wait(&podeProd,&mutex) != 0){
            perror("Error: Could not wait Producer");
            exit(EXIT_FAILURE);
        }
    } 

    strcpy(inputCommands[prodptr], data);
    prodptr++;
    if(prodptr == MAX_COMMANDS) prodptr=0;
    
    numberCommands++;
    
    if(pthread_cond_signal(&podeCons) != 0){
        perror("Error: Could not signal Consumer");
        exit(EXIT_FAILURE);
    }
    unlock_global();
    return 1;
}



char* removeCommand() {
    char* data = malloc(MAX_INPUT_SIZE * sizeof(char));
    lock_global();
    
    while(numberCommands == 0){
        if(pthread_cond_wait(&podeCons,&mutex) != 0){
            perror("Error: Could not wait Consumer");
            exit(EXIT_FAILURE);
        }
    }
    
    strcpy(data,inputCommands[consptr]);
    consptr++;
    if(consptr == MAX_COMMANDS)consptr =0;
    
    numberCommands--;

    if(pthread_cond_signal(&podeProd) != 0){
        perror("Error: COuld not signal Producer");
        exit(EXIT_FAILURE);
    }
    unlock_global();
    return data;
}



void errorParse(){
    fprintf(stderr, "Error: command invalid\n");
    exit(EXIT_FAILURE);
}

void* processInput(){
    char line[MAX_INPUT_SIZE];
    /* break loop with ^Z or ^D */
    FILE *file = fopen(inputFile, "r");
    
    if(file == NULL){
        fprintf(stderr, "Error: Problem with input file\n");
        exit(EXIT_FAILURE);
        return NULL;
    }
    while (fgets(line, sizeof(line)/sizeof(char), file)) {
        char token, type;
        char name[MAX_INPUT_SIZE];

        int numTokens = sscanf(line, "%c %s %c", &token, name, &type);
        /* perform minimal validation */
        if (numTokens < 1) {
            continue;
        }
        switch (token) {
            case 'c':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return NULL;
            
            case 'l':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return NULL;
            
            case 'd':
                if(numTokens != 2)
                    errorParse();
                if(insertCommand(line))
                    break;
                return NULL;
            case 'm':
                if(numTokens != 3)
                    errorParse();
                if(insertCommand(line))
                    break;
                return NULL;
            case '#':
                break;
            
            default: { /* error */
                errorParse();
            }
        }
    }
    /*If a thread reads the command 'E' loop will end = no more arguments to read */
    for (int i = 0; i<MAX_COMMANDS; i++){
        insertCommand("E");
    }
    fclose(file);
    return NULL;
}

void* applyCommands(){
        while(1){
            char* command = removeCommand();
            if (command == NULL)break;
            char token;
            char type[MAX_INPUT_SIZE];
            char name[MAX_INPUT_SIZE];
            int numTokens = sscanf(command, "%c %s %s", &token, name, type);
            if (numTokens > 3) {
                fprintf(stderr, "Error: invalid command in Queue\n");
                exit(EXIT_FAILURE);
            }
            switch (token) {
                case 'c':
                    switch (type[0]){
                        case 'f':
                                create(name, T_FILE);
                                break;

                        case 'd':
                                create(name, T_DIRECTORY);
                                break;
                            
                        default:
                                fprintf(stderr, "Error: invalid node type\n");
                                exit(EXIT_FAILURE);
                    }
                    break;
                case 'l': 
                        lookup_main(name); 
                        break;

                case 'd':
                        delete(name);
                        break;
                case 'm':
                        move(name,type);
                        break;
                case 'E':
                    /* Case that signals that there are no more comands to be read */
                    insertCommand("E");
                    return NULL;
                default: /* error */
                        fprintf(stderr, "Error: command to apply\n");
                        exit(EXIT_FAILURE);                   
            }
        }
}


/* Function that creates and joins threads*/
void init_threads(){
    /* Workerthreads */
    pthread_t* workers = (pthread_t*) malloc(numberThreads * sizeof(pthread_t)); 
    
    /* Initiation of Condition Variables */
    if(pthread_cond_init(&podeProd,NULL)!=0){
        fprintf(stderr, "Can't init cond variable.\n");  
        exit(EXIT_FAILURE);
    }
    if(pthread_cond_init(&podeCons,NULL)!=0){
        fprintf(stderr,"Can't init cond variable.\n");  
        exit(EXIT_FAILURE);       
    }

    /* Starts counting time */
    gettimeofday(&tvalBefore, NULL);

    /* Creates x producer threads (x = number of Threads)*/
    for(int i=0 ; i < numberThreads; i++){
        if (pthread_create(&workers[i], NULL, applyCommands, NULL) != 0){
            fprintf(stderr,"Can't create worker thread");
            exit(EXIT_FAILURE);
        }
    }
    /*Process Input is called*/
    processInput();

    /* Joins workers threads*/
    for(int i=0; i < numberThreads;i++){
        if(pthread_join(workers[i], NULL) != 0){
            fprintf(stderr,"Can't join worker thread");
            exit(EXIT_FAILURE);
        }
    }

    /* Destruction of Condition Variables */
    if(pthread_cond_destroy(&podeProd) != 0){
        fprintf(stderr,"Can't destroy podeProd");
        exit(EXIT_FAILURE);
    }
    if(pthread_cond_destroy(&podeCons) != 0){
        fprintf(stderr,"Can't destroy podeProd");
        exit(EXIT_FAILURE);
    }
    
    /* Prints execution time */
    count_time();  
}



int main(int argc, char* argv[]) {
    /*checks if input is correct*/
    checkinput(argc,argv[1],argv[3]);
 
    /* initiate filesystem */
    init_fs();
    
    /* initiates global MUTEX*/
    init_global();
    
    /* initiates threads*/
    init_threads();
    
    /* prints tree */
    print_tecnicofs_tree(argv[2]);
    
    /* destroys the global MUTEX */
    destroy_global();
    
    /* release allocated memory */
    destroy_fs();
    
    exit(EXIT_SUCCESS);
}
